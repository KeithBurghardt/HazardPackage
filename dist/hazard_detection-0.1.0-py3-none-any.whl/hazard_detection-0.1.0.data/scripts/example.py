from hadet import inference
def main():
    file = ''
    data = pd.read_csv(file)
    predictions = hadet(data)
    

__init__():
    main()
