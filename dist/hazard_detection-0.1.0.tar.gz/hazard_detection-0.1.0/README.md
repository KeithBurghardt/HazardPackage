- hazard_detection.py: code to extract hazards from X posts in JSONL format.
- finalized_model_SVM.sav: the SVM model that detects hazards from XLM-RoBERTa embeddings

